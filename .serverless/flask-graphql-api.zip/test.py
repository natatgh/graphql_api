import requests

# URL do seu servidor GraphQL
url = 'http://localhost:5000/graphql'

# Token de API gerado
api_key = '7a8127d8806485ea4dbba08555278df787fa78de94b4be7787fd9afae4b8e3ce'

# Headers para incluir o token de API
headers = {
    'Content-Type': 'application/json',
    'Authorization': api_key
}

# Função para executar as consultas usando requests
def execute_gql(query, variables):
    response = requests.post(url, json={'query': query, 'variables': variables}, headers=headers)
    return response.json()

# Consulta para criar um usuário
create_user_gql = """
mutation createUser($input: CreateUserInput!, $api_key: String!) {
  createUser(input: $input, api_key: $api_key) {
    id
    name
    email
    error {
      message
      user_name
    }
  }
}
"""

# Parâmetros para a consulta de criação de usuário
create_user_variables = {
    "input": {
        "name": "John Doe",
        "email": "john.doe@example.com",
        "password": "password"
    },
    "api_key": api_key
}

# Executando a consulta de criação de usuário
response_create_user = execute_gql(create_user_gql, create_user_variables)
print("Response for creating user:", response_create_user, "\n")

# Consulta para obter um usuário por ID
get_user_gql = """
query getUser($id: ID!, $api_key: String!) {
  getUser(id: $id, api_key: $api_key) {
    id
    name
    email
  }
}
"""

# Parâmetros para a consulta de obtenção de usuário por ID
get_user_variables = {
    "id": response_create_user['data']['createUser']['id'],  # ID do usuário criado
    "api_key": api_key
}

# Executando a consulta de obtenção de usuário
response_get_user = execute_gql(get_user_gql, get_user_variables)
print("Response for getting user:", response_get_user, "\n")

# Atualização de Usuário
update_user_gql = """
mutation updateUser($id: ID!, $input: UpdateUserInput!, $api_key: String!) {
  updateUser(id: $id, input: $input, api_key: $api_key) {
    id
    name
    email
    error {
      message
    }
  }
}
"""

# Parâmetros para a consulta de atualização de usuário
update_user_variables = {
    "id": response_create_user['data']['createUser']['id'],  # ID do usuário criado
    "input": {
        "name": "John Doe Updated",
        "email": "john.doe.updated@example.com",
        "password": "newpassword"
    },
    "api_key": api_key
}

# Executando a consulta de atualização de usuário
response_update_user = execute_gql(update_user_gql, update_user_variables)
print("Response for updating user:", response_update_user, "\n")

# Consulta para excluir um usuário
delete_user_gql = """
mutation deleteUser($id: ID!, $api_key: String!) {
  deleteUser(id: $id, api_key: $api_key) {
    success
    message
    error {
      message
    }
  }
}
"""

# Parâmetros para a consulta de exclusão de usuário
delete_user_variables = {
    "id": response_create_user['data']['createUser']['id'],  # ID do usuário criado
    "api_key": api_key
}

# Executando a consulta de exclusão de usuário
response_delete_user = execute_gql(delete_user_gql, delete_user_variables)
print("Response for deleting user:", response_delete_user, "\n")
