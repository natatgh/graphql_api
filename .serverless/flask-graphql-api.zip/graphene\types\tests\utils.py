MyLazyType = object()
